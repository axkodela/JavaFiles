import java.util.Scanner;
public class Sort3Integers {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		
		System.out.print("Enter the First integer: ");
		int myFNum = mySc.nextInt();
		
		System.out.print("Enter the Second Integer:");
		int mySNum = mySc.nextInt();
		
		System.out.print("Enter the Third Integer:");
		int myTNum = mySc.nextInt();
		
		if ((myFNum <= mySNum) && (mySNum <= myTNum))
        {
			System.out.println(myFNum);
			System.out.println(mySNum);
			System.out.println(myTNum);
		}
		else if ((mySNum <= myFNum) && (myFNum <= myTNum))
		{
			System.out.println(mySNum);
			System.out.println(myFNum);
			System.out.println(myTNum);
		}
		else if ((myTNum <= myFNum) && (myFNum <= mySNum))
		{
			System.out.println(myTNum);
			System.out.println(myFNum);
			System.out.println(mySNum);
		}
		else if ((myFNum <= myTNum) && (myTNum <= mySNum))
		{
			System.out.println(myFNum);
			System.out.println(myTNum);
			System.out.println(mySNum);
		}
		else if ((mySNum <= myTNum) && (myTNum <= myFNum))
		{
			System.out.println(mySNum);
			System.out.println(myTNum);
			System.out.println(myFNum);
		}
		else {
			System.out.println(myTNum);
			System.out.println(mySNum);
			System.out.println(myFNum);
		}
	}
}
