import java.util.Scanner;
import java.util.Random;
public class RockPaperScissors {
	public static void main(String[] args) {
		String userPlay = "";
		String computerPlay = "";
		int computerInt;
		
		Scanner mySc = new Scanner(System.in);
		Random myRand = new Random();
		
		System.out.println("Hey, Let's play Rock Paper, Scissors.\n" + "Please Enter a move.\n" + "Rock = R, Paper = P, and Scissors = S.");
		computerInt = myRand.nextInt(3)+1;
		
		if (computerInt == 1) {
			computerPlay = "R";
		}
		else if (computerInt == 2) {
			computerPlay = "P";
		}
		else if (computerInt == 3) {
			computerPlay = "S";
		}
		
		System.out.println("Enter Your Play: ");
		userPlay = mySc.next();
		userPlay = userPlay.toUpperCase();
		
		if (userPlay.equals(computerPlay)) {
			System.out.println("It's a Tie!");
		}
		else if ( userPlay.equals("R") && computerPlay.equals("S") ) {
			System.out.println("Rock crushes scissors. You Win!!");
		}
		else if ( userPlay.equals("R") && computerPlay.equals("P") ) {
			System.out.println("Paper beats rock. You Lose!!");
		}
		else if ( userPlay.equals("P") && computerPlay.equals("S") ) {
			System.out.println("Scissor cuts paper. You Lose!!");
		}
		else if ( userPlay.equals("P") && computerPlay.equals("R") ) {
			System.out.println("Rock beats Paper. You Lose!!");
		}
		else if ( userPlay.equals("S") && computerPlay.equals("P") ) {
			System.out.println("Scissor cuts paper. You Win!!");
		}
		else if ( userPlay.equals("S") && computerPlay.equals("R") ) {
			System.out.println("Rock breaks scissors. You Lose!!");
		}
		else {
			 System.out.println("Invalid user input.");
		}
	}
}
