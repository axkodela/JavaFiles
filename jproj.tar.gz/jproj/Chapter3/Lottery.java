import java.util.Scanner;
public class Lottery {
	public static void main(String[] args) {
		int lottery = (int)(Math.random() * 100);
		
		Scanner mySc = new Scanner(System.in);
		System.out.print("Enter your lottery pick (two digits): ");
		int userGuess = mySc.nextInt();
		
		int lotteryNum1 = lottery / 10;
		int lotteryNum2 = lottery % 10;
		
		int guessNum1 = userGuess / 10;
		int guessNum2 = userGuess % 10;
		
		System.out.println("The lottery number is " + lottery);
		
		if (userGuess == lottery) {
			System.out.println("Exact match: You Win $10,000.");
		}
		else if (guessNum2 == lotteryNum1 && guessNum1 == lotteryNum2) {
			System.out.println("Match all digits: You Win $3,000.");
		}
		else if (guessNum1 == lotteryNum1 || guessNum1 == lotteryNum2 || guessNum2 == lotteryNum1 || guessNum2 == lotteryNum2) {
			System.out.println("Match one digit: you win $1,000.");
		}
		else {
			System.out.println("Sorry, no match." + ":(.");
		}
	}
}
