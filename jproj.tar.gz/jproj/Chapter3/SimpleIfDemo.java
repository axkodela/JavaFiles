import java.util.Scanner;
public class SimpleIfDemo{
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		System.out.print("Enter an integer: ");
		int num = mySc.nextInt();
		if (num % 5 == 0) {
			System.out.println("Hi Five!");
		}
		if (num % 2 == 0) {
			System.out.println("Hi Even!");
		}
	}
}
