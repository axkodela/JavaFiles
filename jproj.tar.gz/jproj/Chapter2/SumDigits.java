import java.util.Scanner;
public class SumDigits {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);

        System.out.print("Enter a number between 0 and 1000: ");
        int myNum = mySc.nextInt();
        int myNumDgt1 = myNum % 10;
        int myNumDgt2 = myNum / 10;
        int result = myNumDgt1 + myNumDgt2;
        System.out.println(result);
    }
}
