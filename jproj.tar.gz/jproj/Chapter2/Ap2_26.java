public class Ap2_26{
	public static void main(String[] args) {
		int a = 6;
		int b = a++;
		System.out.println(a);
		System.out.println(b);
		a = 6;
		b = ++a;
		System.out.println(a);
		System.out.println(b);
	}
}

//7
//6
//7
//7
