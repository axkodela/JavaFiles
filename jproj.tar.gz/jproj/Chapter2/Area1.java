import java.util.Scanner;
public class Area1{
	public static void main(String[] args) {
		double radius;
		double area;
		System.out.print("Enter a Radius: ");
		Scanner mySc = new Scanner(System.in);
		radius = mySc.nextFloat();
		area = radius*radius*3.14;
		System.out.println(area);
	}
}
