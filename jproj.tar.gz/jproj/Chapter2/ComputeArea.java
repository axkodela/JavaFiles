public class ComputeArea{
	public static void main(String[] args) {
		double radius = 20;
		double area = radius * radius * 3.14159;
		
		System.out.println("The area of the circle of radius " + radius + " = " + area + ".");
	}
}
