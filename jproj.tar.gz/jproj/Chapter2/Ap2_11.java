public class Ap2_11{
	public static void main(String[] args) {
		System.out.println(56 % 6);
		System.out.println(78 % -4);
		System.out.println(-34 % 5);
		System.out.println(-34 % -5);
		System.out.println(5 % 1);
		System.out.println(1 % 5);
	}
}
