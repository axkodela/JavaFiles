import java.util.Scanner;
public class ComputeAverage{
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		System.out.print("Enter three numbers: ");
		double num1 = mySc.nextDouble();
		double num2 = mySc.nextDouble();
		double num3 = mySc.nextDouble();
		
		double sum = num1+num2+num3;
		double average = sum / 3;
		
		System.out.println("The average of " + num1 + " + " + num2 + " + " + num3 + " is " + average);
	}
}
