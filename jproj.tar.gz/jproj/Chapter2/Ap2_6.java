public class Ap2_6 {
	public static void main(String[] args) {
		int i = 2, j = i, k =j;
		System.out.println(i + " " + j + " " + k);
	}
}
