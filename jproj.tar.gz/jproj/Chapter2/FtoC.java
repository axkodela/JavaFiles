import java.util.Scanner;
public class FtoC{
	public static void main(String[] args) {
		//Scanner mySc = new Scanner(System.in);
		
		//System.out.print("Enter a degrees in fahrenheit: ");
		//double fheit = mySc.nextDouble();
		
		//double Cs = (5.0 / 9) * (fheit - 32);
		//System.out.println("fahrenheit " + fheit + " is " + Cs + " in Celsius.");
		
		int operation1 = 4/(3(r+34));
		int operation2 = 9(a+b(c))
		int operation3 = (3+d(2+a))/a+b(d);
		System.out.println( operation1-operation2+operation3 );
	}
}
