public class ConstantPractice{
	public static void main(String[] args) {
		final int SIZE = 20;
		
		
		
		double miles = 100;
		final double KILOMETERS_PER_MILE = 1.609;
		double kilometers = miles * KILOMETERS_PER_MILE;
		System.out.println(kilometers);
	}
}

/** To answer the question, the benefits of using constants are as follows:
*		you don't have to worry about changing the value after you initialize it.
*/

