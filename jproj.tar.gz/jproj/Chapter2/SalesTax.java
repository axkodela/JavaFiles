import java.util.Scanner;
public class SalesTax{
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		
		System.out.println("Enter purchase amount: ");
		double purchaseAmount = mySc.nextDouble();
		
		double tax = purchaseAmount * 0.096;
		System.out.println("Sales Tax is $" + (int)(tax * 100) / 100.0);
	}
}
