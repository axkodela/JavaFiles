import java.util.Scanner;
public class Ap2_12{
	public static void main(String[] args) {
		System.out.print("Give a number from 1 to 7: ");
		Scanner mySc = new Scanner(System.in);
		int day = mySc.nextInt();
		
		System.out.print("How Many Days Do you want to add to that? ");
		int daysAdding = mySc.nextInt();
		
		int Remaining = daysAdding % 7;
		
		if (Remaining == 0) {
			System.out.println("Same Day");
		}
		
	}
}
