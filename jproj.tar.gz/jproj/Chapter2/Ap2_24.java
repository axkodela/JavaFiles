public class Ap2_24{
	public static void main(String[] args) {
		double a = 6.5;
		a+= a+1;
		System.out.println(a);
		a = 6;
		a /= 2;
		System.out.println(a);
	}
}

// OutPut:
// 14.0
// 3.0
