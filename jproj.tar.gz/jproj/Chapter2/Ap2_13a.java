public class Ap2_13a{
	public static void main(String[] args) {
		float myNum = (float) 25 / 4;
		//System.out.println(myNum);
		
		
		//System.out.println("25 / 4 is " + 25 / 4);
		//System.out.println("25 / 4.0 is " + 25 / 4.0);
		//System.out.println("3 * 2 / 4 is " + 3 * 2 / 4);
		//System.out.println("3.0 * 2 / 4 is " + 3.0 * 2 / 4);
		
		//System.out.println(Math.pow(2, 3.5));
		//int m = 4;
		//int r = 96;
		//System.out.println((float) m*r*r);
		
		
		System.out.println((double) 6.02E23);
	}
}
