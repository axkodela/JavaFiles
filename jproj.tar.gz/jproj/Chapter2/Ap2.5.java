public class Ap2.5{
	public static void main(String[] args) {
		int k = 1;
		int i = k + 2;
		System.out.println(i);
	}
}
