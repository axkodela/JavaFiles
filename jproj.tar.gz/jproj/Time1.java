import java.util.Scanner;

public class Time1{
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int myInt = mySc.nextInt();
		System.out.println("My Int = " + myInt/60 + " minutes and " + myInt % 60  + " seconds.");
	}
}
