import java.util.Scanner;
public class SocialSecurityNum {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		String SSN = mySc.next();
		String[] SubParts = SSN.split("-");
		if (SubParts.length != 3) {
			System.out.println("not okay.");
		}
		else {
			if ((SubParts[0].length() == 3) && (SubParts[1].length() == 2) && (SubParts[2].length() == 4)) {
				try {
					int temp;
					for (int x = 0; x < SubParts.length; x++) {
						temp = Integer.parseInt(SubParts[x]);
					}
					System.out.println("Coorrect SSN");
				}
				catch (Exception e) {
					System.out.println("Wrong SSN");
				}
			}
			else {
				System.out.println("Wrong SSN");
			}
		}
	}
}
