import java.util.Random;
public class GenVehiclePlateNumbers {
	public static void main(String[] args) {
		String VehiclePlate = "";
		for (int x = 0; x < 3; x++) {
			int letterNumber = 65 +  (int)(Math.random() * (90 - 65));
			char letter = (char) letterNumber;
			VehiclePlate += letter;
		}
		for (int x = 0; x < 4; x++) {
			int Number = (int) (Math.random() * 10);
			VehiclePlate += Number;
		}
		System.out.println(VehiclePlate);
	}
}
