import java.util.Scanner;
public class LetterGrade {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		System.out.println("Enter a letter grade: ");
		String letterGrade = mySc.nextLine();
		
		if (letterGrade.charAt(0) == "A") {
			System.out.println("The numeric value for grade " + letterGrade + " is " + "4" + ". ");
		}
		else if (letterGrade.charAt(0) == "B") {
			System.out.println("The numeric value for grade " + letterGrade + " is " + "3" + ". ");
		}
		else if (letterGrade.charAt(0) == "C") {
			System.out.println("The numeric value for grade " + letterGrade + " is " + "2" + ". ");
		}
		else if (letterGrade.charAt(0) == "D") {
			System.out.println("The numeric value for grade " + letterGrade + " is " + "1" + ". ");
		}
		else if (letterGrade.charAt(0) == "F") {
			System.out.println("The numeric value for grade " + letterGrade + " is " + "0" + ". ");
		}
		else if (letterGrade.charAt(0) == "E" || letterGrade.charAt() > "F") {
			System.out.println("Invalid Letter Grade.");
		}
	}
}
