public class Grade {
	public static void main(String[] args) {
		enum Grade {
			APLUS("A+", 4.3),
			A("A", 4.0),
			AMINUS("A-", 3.7),
			BPLUS("B+", 3.3),
			B("B", 3.0),
			BMINUS("B-", 2.7),
			CPLUS("C+", 2.3),
			C("C", 2.0),
			CMINUS("C-", 1.7),
			DPLUS("D+", 1.3),
			D("D", 1.0),
			DMINUS("D-", 0.7),
			F("F", 0.0);
		}
		
		private final String symbol;
		private final double value;
		
		Grade(String symbol, double value) {
			this.symbol = symbol;
			this.value = value;
		}
		
		public String getSymbol() {
			return symbol;
		}
		
		public double getValue() {
			return value;
		}
	}
}
