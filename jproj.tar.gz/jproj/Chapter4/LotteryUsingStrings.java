import java.util.Scanner;
public class LotteryUsingStrings {
	public static void main(String[] args) {
		
	}
}
