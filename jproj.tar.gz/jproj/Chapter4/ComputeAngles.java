import java.util.Scanner;
public class CoumputeAngles {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		
		System.out.print("Enter three points: ");
		
	}
}
