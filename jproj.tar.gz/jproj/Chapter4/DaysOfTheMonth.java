import java.util.Scanner;
public class DaysOfTheMonth {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		
		System.out.println("Enter a year: ");
		int myYear = mySc.nextInt();
		
		System.out.println("Enter a month: ");
		String myMonth = mySc.next();
/*
		String Jan = "Jan";
		String Feb = "Feb";
		String Mar = "Mar";
		String Apr = "Apr";
		String May = "May";
		String Jun = "Jun";
		String Jul = "Jul";
		String Aug = "Aug";
		String Sep = "Sep";
		String Oct = "Oct";
		String Nov = "Nov";
		String Dec = "Dec";
*/
		
		
		if (myYear % 4 == 0 && myMonth.equals("Feb")) {
			System.out.println(myMonth + " " + myYear + " has 29 days. ");
		}
		else if (myMonth.equals("Jan") || myMonth.equals("Mar") || myMonth.equals("May") || myMonth.equals("Jul") || myMonth.equals("Aug") || myMonth.equals("Oct") || myMonth.equals("Dec") ) {
			System.out.println(myMonth + " " + myYear + " has 31 days. ");
		}
		else if (myMonth.equals("Apr") || myMonth.equals("Jun") || myMonth.equals("Sep") || myMonth.equals("Nov")) {
			System.out.println(myMonth + " " + myYear + " has 30 days. ");
		}
		else if (myYear % 4 != 0 && myMonth.equals("Feb")) {
			System.out.println(myMonth + " " + myYear + " has 28 days. ");
		}
	}
}
