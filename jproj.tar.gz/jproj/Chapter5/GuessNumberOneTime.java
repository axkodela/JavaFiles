import java.util.Scanner;
public class GuessNumberOneTime {
	public static void main(String[] args) {
		int myNum = (int)(Math.random() * 101);
		Scanner mySc = new Scanner(System.in);
		
		System.out.println("Guess a magic number between 0 and 100");
		System.out.print("\nEnter your guess: ");
		int myGuess = mySc.nextInt();
		
		while (myGuess != myNum) {
			System.out.print("\nEnter your guess: ");
			myGuess = mySc.nextInt();
			if (myGuess == myNum) {
				System.out.println("Yes, the number is " + number);
			}
			else if (myGuess > myNum) {
				System.out.println("Your guess is too high");
			}
			else{
				System.out.println("Your guess is too low");
			}
		}
	}
}
