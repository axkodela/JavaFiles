import java.util.HashMap;
public class FinanceApplication {
	public static void main(String[] args) {
		HashMap<Integer, Integer> myTuition = new HashMap<>();
		int curTuition = 10000;
		int yrIncrease = 5;
		
		for (int x = 1; x<15; x++) {
			curTuition += getPerc(curTuition, yrIncrease);
			myTuition.put(x , curTuition);
		}
		
/*
		for (int k : myTuition.keySet()) {
			System.out.println("" + k + " " + myTuition.get(k));
		}
*/
		
		double total = 0;
		for (int x = 11; x <15; x++) {
			total += myTuition.get(x);
		}
		System.out.println(total);
	}
	public static double getPerc(double amt, double percent) {
		double result = (amt * percent) / 100;
		return result;
	}
}
