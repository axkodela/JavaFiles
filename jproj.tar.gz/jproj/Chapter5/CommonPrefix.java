import java.util.Scanner;
public class CommonPrefix {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		
		String result = "";
		
		System.out.print("Enter the first string: ");
		String firstString = mySc.nextLine();
		
		System.out.print("Enter the second string: ");
		String secondString = mySc.nextLine();
		
		int frstStrSze = firstString.length();
		int secStrSze = secondString.length();
		
		for (int x = 0; x < Math.min(frstStrSze, secStrSze); x++) {
			if (firstString.charAt(x) == secondString.charAt(x)) {
				result += firstString.charAt(x);
			}
		}
		
		System.out.println("The Common prefixes are " + result);
	}
}
