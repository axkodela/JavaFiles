public class PrimeNumber {
	public static void main(String[] args) {
		final int NUMBER_OF_PRIMES = 50;
		final int NUMBER_OF_PRIMES_PER_LINE = 10;
		int count = 0 ;
		int myNum = 2;
		
		System.out.println("The first 50 primes numbers are: \n");
		
		while (count < NUMBER_OF_PRIMES) {
			boolean isPrime = true;
			
			for (int divisor = 2; divisor <= myNum/2; divisor++) {
				if (myNum % divisor == 0) {
					isPrime = false;
					break;
				}
			}
			
			if (isPrime) {
				count++;
				
				if (count % NUMBER_OF_PRIMES_PER_LINE == 0) {
					System.out.print("\n");
					System.out.print(myNum);
					System.out.print("\n");
				}
				else {
					System.out.print(myNum + " ");
				}
			}
			myNum++;
		}
	}
}
