import java.util.Scanner;
public class CompareLoansWithVariusInterestRates {
	public static void main(String[] args) {
		Scanner mySc = new Scanner(System.in);
		System.out.println("Loan Amount:  ");
		double usrLoan = mySc.nextDouble();
		
		System.out.println("Number of years:  ");
		int numOfYears = mySc.nextInt();
		
		for (double x = 5.0; x <= 8.0; x+=0.125) {
			double myMonthly = 0;
			double myTotal = 0;
			double monthlyIR = x/1200;
			myMonthly = getMonthly(monthlyIR, usrLoan, numOfYears);
			myTotal = getTotal(myMonthly, numOfYears);
			//System.out.println(x + "\t" + myMonthly + "\t" + myTotal);
			System.out.printf("%.2f\t%.2f\t%.2f\n", x, myMonthly, myTotal);
		}
	}
	
	public static double getMonthly(double monthlyIntRate, double loanAmt ,int numOfYears) {
		double result = loanAmt * monthlyIntRate / (1 - 1 / Math.pow(1 + monthlyIntRate, numOfYears * 12));
		return result;
	}
	
	public static double getTotal(double monthlyPay, int numOfYears) {
		double totalPayment = monthlyPay * numOfYears * 12;
		return totalPayment;
	}
}
