public class Ap2_10{
	public static void main(String[] args) {
		
	}
}
