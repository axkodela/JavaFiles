package chatbot1;
import java.util.*;

public class ChatBot1 {

    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String userInput = "";
        HashMap<String,String> myHash = new HashMap<>();
        
   
        myHash.put("hello", "howdy dude");
        myHash.put("bye", "FINALLY, Your Leaving");
        myHash.put("howdy?","Good Bro");
        
        userInput = mySc.nextLine();
        while (! userInput.equals("quit")) {
            if (myHash.containsKey(userInput)) {
                String getKey = myHash.get(userInput);
                System.out.println(getKey);
                
            }
            userInput = mySc.nextLine();
        }
    }
}