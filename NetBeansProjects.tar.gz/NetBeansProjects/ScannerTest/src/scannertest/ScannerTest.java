package scannertest;

import java.util.*;

public class ScannerTest {

    public static void main(String[] args) {
        //variables
        Scanner mySc = new Scanner(System.in);
        String myGreeting = "Hello There, Human. Welcome to Java. Tell us your age:";
        int userAge = 0;
        
        //ask for and store user age
        System.out.println(myGreeting);
        userAge = mySc.nextInt();
        
        //see if user >21 - they can get pilot license, <16 - cant drive, >90 - stop driving, >35 - drive better
        while (userAge != 0){
            if (userAge < 16) {
                System.out.println("You Cannot Drive yet.");
            }
            else if ((userAge >= 16) && (userAge < 21)) {
                System.out.println("You can get a Driver's license.");
            }
            else if ((userAge >= 21) && (userAge < 35)) {
                System.out.println("Drive Better.");
            }
            else if ((userAge >= 35) && (userAge < 90)){
                System.out.println("Drive Safely.");
            }
            else if (userAge >= 90){
                System.out.println("Stop Driving.");
            }
            else {
                System.out.println("I cannot understand your age input.");
            }
            System.out.println(myGreeting);
            userAge = mySc.nextInt();
        }
        if (userAge == 0) {
            System.out.println("You are not born yet.");
        }
    }
}




