/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringcaseandlength;
import java.util.*;
/**
 *
 * @author akash
 */
public class StringCaseAndLength {

	public static void main (String[] args) {
		// variables.
		Scanner mySc = new Scanner(System.in);
		String AskForInput = "Say something";
		String userInput = "";
		String upperCaseStr = "";
		String lowerCaseStr = "";
		int stringLen = 0;
		
		// ask for and store the user input.
		System.out.println(AskForInput);
		userInput = mySc.next();
		
		// print the original string.
		System.out.println(userInput);
		
		// print out the uppercase version of the user input string.
		upperCaseStr = userInput.toUpperCase();
		System.out.println(upperCaseStr);
		
		// print out the lowercase version of the user input string.
		lowerCaseStr = userInput.toLowerCase();
		System.out.println(lowerCaseStr);
		
		// print out the length of the string.
		stringLen = userInput.length();
		System.out.println(stringLen);
	}
    
}
