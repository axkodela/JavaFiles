package Whiteboard;

import java.awt.Color;
import static java.awt.Color.red;
import static java.lang.System.exit;

public class mainFile extends javax.swing.JFrame {
    public mainFile() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jMenu1 = new javax.swing.JMenu();
        Painto = new java.awt.Canvas();
        XButton = new javax.swing.JButton();
        MenuBar = new javax.swing.JMenuBar();
        MenuTop = new javax.swing.JMenu();
        Color = new javax.swing.JMenu();
        RedColor = new javax.swing.JMenuItem();
        BlueColor = new javax.swing.JMenuItem();
        GreenColor = new javax.swing.JMenuItem();
        ToolMenu = new javax.swing.JMenu();
        PaintBrush = new javax.swing.JMenuItem();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        XButton.setText("X");
        XButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                XButtonMouseClicked(evt);
            }
        });

        MenuBar.setBorderPainted(false);
        MenuBar.setInheritsPopupMenu(true);

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, XButton, org.jdesktop.beansbinding.ObjectProperty.create(), MenuBar, org.jdesktop.beansbinding.BeanProperty.create("background"));
        bindingGroup.addBinding(binding);

        MenuTop.setText("Menu");

        Color.setText("Color");

        RedColor.setText("Red");
        RedColor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RedColorMouseClicked(evt);
            }
        });
        Color.add(RedColor);

        BlueColor.setText("Blue");
        Color.add(BlueColor);

        GreenColor.setText("Green");
        Color.add(GreenColor);

        MenuTop.add(Color);

        ToolMenu.setText("Tools");

        PaintBrush.setText("Paint Brush");
        ToolMenu.add(PaintBrush);

        MenuTop.add(ToolMenu);

        MenuBar.add(MenuTop);

        setJMenuBar(MenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(599, 599, 599)
                .addComponent(XButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Painto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(XButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Painto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        XButton.getAccessibleContext().setAccessibleParent(MenuBar);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void XButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XButtonMouseClicked
        exit(0);
    }//GEN-LAST:event_XButtonMouseClicked

    private void RedColorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RedColorMouseClicked
        Color myColor = Color.setColor(Color.getGraphics().setColor(red));
    }//GEN-LAST:event_RedColorMouseClicked
    
    
    
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mainFile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mainFile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mainFile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainFile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new mainFile().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem BlueColor;
    private javax.swing.JMenu Color;
    private javax.swing.JMenuItem GreenColor;
    private javax.swing.JMenuBar MenuBar;
    private javax.swing.JMenu MenuTop;
    private javax.swing.JMenuItem PaintBrush;
    private java.awt.Canvas Painto;
    private javax.swing.JMenuItem RedColor;
    private javax.swing.JMenu ToolMenu;
    private javax.swing.JButton XButton;
    private javax.swing.JMenu jMenu1;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}