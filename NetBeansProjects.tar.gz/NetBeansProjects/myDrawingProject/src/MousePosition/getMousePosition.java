package MousePosition;

import java.awt.MouseInfo;
import java.awt.Rectangle;
import static java.lang.System.exit;

public class getMousePosition extends javax.swing.JFrame {

    public getMousePosition() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        XPositionLbl = new javax.swing.JLabel();
        YPositionLbl = new javax.swing.JLabel();
        PanelfrPos = new javax.swing.JPanel();
        ExitB = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        XPositionLbl.setText("X Position = ");
        XPositionLbl.setToolTipText("X Position = ");

        YPositionLbl.setText("Y Position = ");
        YPositionLbl.setToolTipText("Y Position = ");

        PanelfrPos.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PanelfrPosMouseMoved(evt);
            }
        });
        PanelfrPos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelfrPosMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout PanelfrPosLayout = new javax.swing.GroupLayout(PanelfrPos);
        PanelfrPos.setLayout(PanelfrPosLayout);
        PanelfrPosLayout.setHorizontalGroup(
            PanelfrPosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        PanelfrPosLayout.setVerticalGroup(
            PanelfrPosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 258, Short.MAX_VALUE)
        );

        ExitB.setText("Exit");
        ExitB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitBMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(XPositionLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(YPositionLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 252, Short.MAX_VALUE)
                .addComponent(ExitB))
            .addComponent(PanelfrPos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(XPositionLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(YPositionLbl))
                    .addComponent(ExitB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelfrPos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PanelfrPosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelfrPosMouseClicked
        System.out.println("You have Clicked at "+ PanelfrPos.getMousePosition());
    }//GEN-LAST:event_PanelfrPosMouseClicked

    private void PanelfrPosMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelfrPosMouseMoved
        Rectangle bounds = PanelfrPos.bounds();
        if (PanelfrPos.getMousePosition().x < bounds.width) {
            XPositionLbl.setText(XPositionLbl.getToolTipText()+evt.getX());
        }
        if (PanelfrPos.getMousePosition().y < bounds.height) {
            YPositionLbl.setText(YPositionLbl.getToolTipText()+evt.getY());
        }
    }//GEN-LAST:event_PanelfrPosMouseMoved

    private void ExitBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitBMouseClicked
        exit(0);
    }//GEN-LAST:event_ExitBMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(getMousePosition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(getMousePosition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(getMousePosition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(getMousePosition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new getMousePosition().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitB;
    private javax.swing.JPanel PanelfrPos;
    private javax.swing.JLabel XPositionLbl;
    private javax.swing.JLabel YPositionLbl;
    // End of variables declaration//GEN-END:variables
}
