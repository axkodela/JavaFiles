package evenoddtester;
import static java.lang.System.exit;
import java.util.*;

public class EvenOddTester {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = "UserName: ";
        String userInput = "";
        String passWord = "Password: ";
        
        System.out.println(askInput);
        userInput = mySc.next();
        while (!(userInput.equals("Quit"))) {
            if (userInput.equals("akash")) {
                System.out.println("Welcome.");
                exit(0);
            } 
            else {
                System.out.println(passWord);
                userInput = mySc.next();
            }
            System.out.println(askInput);
            userInput = mySc.next();
        }

    }
    
}
