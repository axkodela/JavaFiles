package helloworld;

public class HelloWorld {

    public static void main(String[] args) {
        myPrint p1 = new myPrint();
        sayHi("hohoho");
        
        p1.SayIt("Hello");
        int argNum = args.length;
        while (argNum >= 1) {
            p1.SayIt(args[argNum-1]);
            argNum -=1;
        
        }
    }
    
    private static void sayHi(String name){
        System.out.println(name);
    }

}


class myPrint {
    public void SayIt(String msg) 
    {
        System.out.println(msg);
    }

}