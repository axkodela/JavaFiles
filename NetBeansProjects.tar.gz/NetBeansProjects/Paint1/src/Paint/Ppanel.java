package Paint;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Ppanel extends JPanel {
    //Graphics gh;
    
    public Ppanel(){
    
    }
    public void paintComponent(Graphics gx) {
        //gh = gx;
        super.paintComponent(gx);
       
    }
    
    public void Line(Color c, int x1, int y1, int x2, int y2) {
        Graphics gh = this.getGraphics();
        gh.setColor(c);
        gh.drawLine(x1, y1, x2, y2);
    }
    
}
