package trycatch;

import java.util.*;

public class TryCatch {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = ">>  ";
        String userInput = "";
        
        System.out.print(askInput);
        userInput = mySc.next();
        
        // if user inputs a number, then print you gave a number. if user inputs a string, then print 
        try {
            Integer.parseInt(userInput);
            System.out.println("You gave an integer.");
        }
        catch(Exception e) {
            System.out.println("You gave a String, not a Number.");
        }
    }
    
}
