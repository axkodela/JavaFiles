package mypractice1;

public class MyPractice1 {
    public static void main(String[] args) {
        int myInt1 = 50;
        int myInt2 = 50;
        String myString1 = "1 is Smaller than 2.";
        String myString2 = "1 is Greater than 2.";
        String myString3 = "1 and 2 are the same.";
        
        if (myInt1<myInt2)
        {
            System.out.println(myString1);
        }
        else if (myInt1>myInt2)
        {
            System.out.println(myString2);
        }
        else
        {
            System.out.println(myString3);
        }
        
        /**
        .............or...........
        
        else if (myInt1 == myInt2)
            {
                System.out.println(myString3);
            }
        */
    }  
}
