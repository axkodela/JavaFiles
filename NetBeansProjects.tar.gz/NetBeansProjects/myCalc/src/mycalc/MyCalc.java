package mycalc;
import java.util.*;

public class MyCalc {

    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = ">> ";
        String userInput = "";
        List<String> myStack = new ArrayList<String>();
        List<String> WorkStack = new ArrayList<String>();
        
        // ask for and store input.
        System.out.print(askInput);
        userInput = mySc.nextLine();
        
        
        // Split the string input.
        String[] myParts = userInput.split(" ");
        for (int x = 0; x < myParts.length; x++) {
            myStack.add(myParts[x]);
            
        }
        for (int x = 0; x < myStack.size(); x++) {
            try {
            int tempNum = Integer.parseInt(myStack.get(x));
            myStack.remove(x);
            }
            catch(Exception e) {
            
            
            }
        }
        
        
        
    }
    
}
