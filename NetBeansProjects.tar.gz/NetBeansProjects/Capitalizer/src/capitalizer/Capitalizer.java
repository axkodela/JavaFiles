package capitalizer;

import java.util.*;

public class Capitalizer {

    public static void main(String[] args) {
        // variables.
        Scanner mySc = new Scanner(System.in);
        myCap myC = new myCap();
        String askInput = "Type Something:";
        String userInput = "";
        
        //ask for and store the user input.
        System.out.println(askInput);
        userInput = mySc.nextLine();
        
        System.out.println(myC.Capitalize(userInput));
    }
}