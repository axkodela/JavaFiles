package capitalizer;

public class myCap {
    public String Capitalize(String userInput) {
        // Variables.
        String firstLetter = "";
        String Rest = "";
        String[] myArray = userInput.split(" ");
        String StringResult = "";
        for (int n = 0; n < myArray.length; n++) {
            String currentWord = myArray[n];
            // splice the user input string and store the first letter in firstLetter and the rest of the string in Rest.
            firstLetter = currentWord.substring(0, 1);
            Rest = currentWord.substring(1, currentWord.length());

            // Capitalize both firstLetter and Rest. Then Reassign.
            firstLetter = firstLetter.toUpperCase();
            Rest = Rest.toLowerCase();
            //System.out.println(firstLetter + Rest);
            StringResult += firstLetter + Rest + " ";
        }

        // Print out the result(s).
        return(StringResult);
    }
}
