package myarrays;
import java.util.*;
public class MyArrays {
    public static void main(String[] args) {
        List<String> myArray = new ArrayList<>();
        
        
        for (int x = 0; x< args.length; x++) {
            myArray.add(args[x]);
        }
        for (int x = 0; x< myArray.size(); x++) {
            System.out.println(myArray.get(x));
        }
    }
}