package myfileopener;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyFileOpener {
    public static void main(String[] args) throws IOException {
        File myFile = new File("/home/akash/blankFile.txt");
        try {myFile.createNewFile();} catch (Exception e) {System.err.println(e.getMessage());}
        System.out.println("File Path: "+myFile.getPath());
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("/home/akash/blankFile.txt"))) {
            bw.write("There is something in this file. Hello World. How are You doing today?");
            bw.newLine();
            bw.write("hello.");
            bw.newLine();
            bw.write("How Are You Doing Today?");
            bw.close();
        }
        catch (IOException e) {
            Logger.getLogger(MyFileOpener.class.getName()).log(Level.SEVERE, null, e);
        }
        System.out.println();
        
    }
}