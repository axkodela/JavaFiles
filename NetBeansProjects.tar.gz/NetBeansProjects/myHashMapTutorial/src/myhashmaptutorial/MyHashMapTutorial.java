package myhashmaptutorial;
import java.util.*;
import static javafx.application.Platform.exit;
public class MyHashMapTutorial {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = "Type Something";
        String userInput = "";
        HashMap<String,Integer> myHash = new HashMap<>();
        
        System.out.println(askInput);
        userInput = mySc.nextLine();
        
        if (userInput.equals('p')){
            for (int x=0;x<myHash.size(); x++){
                System.out.println(myHash.get(x));
            }
        }
        else if (userInput.equals('q')) {
            exit();
        }
        
        if (userInput.contains(",")) {
            String[] userParts = userInput.split(",");
            Integer put = myHash.put(userParts[0], Integer.parseInt(userParts[1]));
        }
    }
}
