package basics;

public class Basics {

    public static void main(String[] args) {
        int myInt = 0;
        float myFl = 16.42f;
        float myFlAddition = 10.00f + 6.00f + 0.42f + 0.15f;
        String myString = "blah di blah";
        
        typeChecker myTC = new typeChecker();
        myTC.checkType(myInt);
        myTC.checkType(myFl);
        myTC.checkType(myFlAddition);
        myTC.checkType(myString);
        
    }

}
