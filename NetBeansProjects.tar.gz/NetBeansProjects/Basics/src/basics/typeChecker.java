package basics;

public class typeChecker {
        public void checkType(Object myObj) {
        if ( Integer.class.isInstance(myObj) ) {
            System.out.println("object is of type: Integer.");
        }
        else if ( String.class.isInstance(myObj) ) {
            System.out.println("object is of type: String.");
        }
        else if ( Float.class.isInstance(myObj) ) {
            System.out.println("object is of type: Float.");
        }
    }
}
