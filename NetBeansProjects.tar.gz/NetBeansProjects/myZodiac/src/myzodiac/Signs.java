package myzodiac;

import java.util.HashMap;

public class Signs {
    HashMap<Integer, String> mySigns = new HashMap<>();
    
    Signs(){
        mySigns.put(1, "Aquarius");
        mySigns.put(2, "Pisces");
        mySigns.put(3, "Aries");
        mySigns.put(4, "Taurus");
        mySigns.put(5, "Gemini");
        mySigns.put(6, "Cancer");
        mySigns.put(7, "Leo");
        mySigns.put(8, "Virgo");
        mySigns.put(9, "Libra");
        mySigns.put(10, "Scorpio");
        mySigns.put(11, "Sagittarius");
        mySigns.put(12, "Capricorn");
    }

    public String get(int myMonth) {
        if (mySigns.containsKey(myMonth)) {
            return(mySigns.get(myMonth));
        }
        else {
            return "Numbered Month is not in dictionary.";
        }
    }
}