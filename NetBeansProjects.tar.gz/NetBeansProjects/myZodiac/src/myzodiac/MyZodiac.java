package myzodiac;

import java.util.*;

public class MyZodiac {

    public static void main(String[] args) {
        // variables
        Scanner mySc = new Scanner(System.in);
        Signs mySigns = new Signs();
        Stones myStones = new Stones();
        String askInput = "Type a month in numberd format representing your birthday:    [ Type 0 to quit ]";
        int userInput = 0;
        
        // ask for and store the user input.
        System.out.println(askInput);
        userInput = mySc.nextInt();

        /* test to see if user input is in hashmap. if it is, then return/print the value.
           if it is not, then return -1.         */

        
        while ( userInput != 0 ){
            if (mySigns.mySigns.containsKey(userInput)) {
                System.out.println(mySigns.get(userInput));
            } 
            else {
                System.out.println("Numbered Month is not in dictionary.");
            }

            if (myStones.myStones.containsKey(userInput)) {
                System.out.println(myStones.get(userInput));
            } 
            else {
                System.out.println("Numbered Month is not in dictionary.");
            }
            
            System.out.println(askInput);
                
            try{
                userInput = mySc.nextInt();
                System.out.println(userInput);
            }
            catch(Exception e){
                mySc.nextLine();
                System.out.println("Please Type a Number.");
            }
        }
    }
}