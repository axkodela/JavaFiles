package myzodiac;
import java.util.*;

public class Stones {
    HashMap<Integer, String> myStones= new HashMap<>();
    
    Stones(){
        myStones.put(1, "Amethyst");
        myStones.put(2, "Aquamarine");
        myStones.put(3, "Diamond");
        myStones.put(4, "Emerald");
        myStones.put(5, "Pearl");
        myStones.put(6, "Ruby");
        myStones.put(7, "Peridot");
        myStones.put(8, "Sapphire");
        myStones.put(9, "Opal");
        myStones.put(10, "Topaz");
        myStones.put(11, "Turquoise");
        myStones.put(12, "Garnet");
    }
    
    public String get(int myMonth) {
        if (myStones.containsKey(myMonth)) {
            return myStones.get(myMonth);
        }
        else {
            return "Numbered Month is not in Dictionary.";
        }
    }
}