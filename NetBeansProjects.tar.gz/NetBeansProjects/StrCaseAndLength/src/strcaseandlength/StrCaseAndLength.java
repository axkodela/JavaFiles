package strcaseandlength;

import static java.lang.System.exit;
import java.util.*;

public class StrCaseAndLength {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String userInput = "";
        
        
        while (mySc.hasNext() ) {
            userInput = mySc.next();
            if (userInput.equals("quit")) {
                exit(0);
            }
            else {
                String FLet = "";
                String Rest = "";
                
                FLet = userInput.substring(0,1);
                Rest = userInput.substring(1, userInput.length());
                FLet = FLet.toUpperCase();
                Rest = Rest.toLowerCase();
                
                System.out.println(FLet + Rest);
                
                
                
            }
        }
    }
}
