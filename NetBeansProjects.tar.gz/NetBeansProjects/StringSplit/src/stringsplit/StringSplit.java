/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringsplit;

/**
 *
 * @author akash
 */
public class StringSplit {
    public static void main(String[] args) {
        // TODO code application logic here
        String myString = "hello there blah di blah";
        String[] myParts = myString.split(" ");
        System.out.println(myParts.length);
        
        
        for (int n = 0; n < myParts.length; n++) {
            System.out.println(myParts[n]);
        }
    }
    
}
