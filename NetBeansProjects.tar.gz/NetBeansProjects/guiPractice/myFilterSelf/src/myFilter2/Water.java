/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myFilter2;

/**
 *
 * @author akash
 */
public class Water {
    boolean clean;
    int Amount;
}
