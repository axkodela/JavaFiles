/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myFilter2;

/**
 *
 * @author akash
 */
public class Filter {
    public Water doFilter(Water w) {
        if (w.clean == false) {
            w.clean = true;
        }
        return w;
    }
}