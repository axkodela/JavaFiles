package myprctice4;

import java.util.*;

public class MyPrctice4 {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = "Type Something:";
        String userInput = "";
        
        System.out.println(askInput);
        userInput = mySc.nextLine();
        
        String [] userParts = userInput.split(" ");
        int[] userPartsNum = new int[userParts.length];
        for (int x = 0; x<userParts.length; x++){
            try {
                userPartsNum[x] = Integer.parseInt(userParts[x]);
            }
            catch (Exception e) {
                
            }
        }
        for (int x = 0; x<userPartsNum.length; x++) {
            System.out.print(userPartsNum[x] + " ");
        }
    }
    
}
