package myrandom;
import java.util.*;
@SuppressWarnings("UnusedAssignment")


public class MyRandom {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = "Type Something:";
        String userInput = "";
        char CharacterReturn;

        System.out.println(askInput);
        userInput = mySc.nextLine();
        
        //CharacterReturn = userInput.;
    }
}