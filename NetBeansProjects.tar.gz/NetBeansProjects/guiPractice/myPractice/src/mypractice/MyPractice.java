package mypractice;
import java.util.*;

public class MyPractice {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = "Type Something:";
        String userInput = "";
        mySort myVSort = new mySort();
        
        //System.out.println(askInput);
        //userInput = mySc.nextLine();
        userInput = "3 4 7 1";
        String[] userParts = userInput.split(" ");
        int[] numParts = new int[userParts.length];
        
        for (int x = 0; x < userParts.length; x++) {
            numParts[x] = Integer.parseInt(userParts[x]);
            //System.out.println(numParts[x]);
        }
        myVSort.Sort(numParts);
    }
}
