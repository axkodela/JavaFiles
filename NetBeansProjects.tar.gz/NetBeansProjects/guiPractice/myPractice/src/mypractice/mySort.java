/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypractice;

/**
 *
 * @author akash
 */
public class mySort {
    public int[] Sort(int[] inNum) {
        // assume array is not in numerical order.
        boolean changed = true;
        
        while (changed == true) {
            changed = false;
            for (int x =1; x<inNum.length; x++) {
                if (inNum[x-1] > inNum[x]) {
                    changed = true;
                    int tempNum = inNum[x-1];
                    inNum[x-1] = inNum[x];
                    inNum[x] = tempNum;
                }
            }
        }
        
        for (int x = 0; x < inNum.length; x++) {
            System.out.println(inNum[x]);
        }

        return inNum;
    }
}