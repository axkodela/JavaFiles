package chatbot2;

import java.util.*;

public class ChatBot2 {
    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String userInput = "";
        HashMap<String, String> myHash2 = new HashMap<>();
        
        myHash2.put("hi","Ughh, we're doing this again?????!!!!!");
        myHash2.put("bye","GoodBye... FOREVER!!!!");
        myHash2.put("stupid","I'm not Insulting you. I'm merely Describing you.");
        
        userInput = mySc.nextLine();
        while (! userInput.equals("quit")) {
            if (myHash2.containsKey(userInput)) {
                String myKey = myHash2.get(userInput);
                System.out.println(myKey);
            }
            userInput = mySc.nextLine();
        }
    }
    
}
