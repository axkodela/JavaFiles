package mycaloriesmain;
import java.util.*;

public class foodVal {
    HashMap<String, Integer> foodValues = new HashMap<>();
    
    foodVal(){
        foodValues.put("almonds", 165);
        foodValues.put("apricot", 50);
        foodValues.put("butter", 35);
        foodValues.put("cabbage", 15);
        foodValues.put("carrot cake", 6175);
        foodValues.put("cauliflower", 30);
        foodValues.put("cheesecake 1 piece", 280);
    }
    
    public Integer get(String myString){
        if (foodValues.containsKey(myString)) {
            return(foodValues.get(myString));
        }
        else {
            return -1;
        }
    }
}