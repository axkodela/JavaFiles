package mycaloriesmain;
import java.util.*;

public class MyCaloriesMain {

    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        foodVal myFV = new foodVal();
        String askFood = "Type a food to get the number of Calories:";
        String userInput;
        int totalCalories = 0;
        
        System.out.println(askFood);
        userInput = mySc.nextLine();
        if (userInput.contains(",")){
            String[] userParts = userInput.split(",");
            
            for (int x = 0; x < userParts.length; x++) {
                int tempCal = myFV.get(userParts[x].trim());

                if (tempCal != -1) {
                    totalCalories += tempCal;
                    System.out.println(userParts[x] + " "+ tempCal);
                }
            }
            System.out.println(totalCalories);
        }
        else {
            int tempCal = myFV.get(userInput);
            if (tempCal != -1) {
                System.out.println(tempCal);
            }
        }
    }
}
