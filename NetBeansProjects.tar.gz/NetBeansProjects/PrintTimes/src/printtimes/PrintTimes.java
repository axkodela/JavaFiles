package printtimes;
import java.util.*;
public class PrintTimes {

    public static void main(String[] args) {
        // variables.
        Scanner mySc = new Scanner(System.in);
        String Askname = "What is your name?";
        String myName = "";
        String AskForNum = "How many times do you want your name printed?";
        int printNum = 0;
        
        // ask for and store the name and print times.
        System.out.println(Askname);
        myName = mySc.next();
        System.out.println(AskForNum);
        printNum = mySc.nextInt();
        
        // test to see if the printing works.
        //System.out.println(myName);
        //System.out.println(printNum);
        
        /** print myName however many times the user has inputed:
         *  but if printNum is 0 then say that the users name cannot be printed 0 times
         */
        if (printNum != 0) {
            for (int x = 0; x < printNum; x++) {
                System.out.println(myName);
            }
        }
        else {
            System.out.println("Cannot print your name 0 times. Please try again later.");
        }
    }
    
}
