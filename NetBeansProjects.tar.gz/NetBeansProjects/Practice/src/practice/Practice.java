package practice;

import static java.lang.System.exit;
import java.util.*;

public class Practice {

    public static void main(String[] args) {
        Scanner mySc = new Scanner(System.in);
        String askInput = "Type Something";
        String userInput = "";
        HashMap<String, Integer> myHash = new HashMap<>();
        
        System.out.println(askInput);
        userInput = mySc.nextLine();
        
        if (userInput.contains(",")) {
            String[] userParts = new String[userInput.length()];
            userParts = userInput.split(",");
            for (int x = 0; x<userParts.length; x++){
                myHash.put(userParts[x], x);
            }
            System.out.println(myHash);
        }
        else if (!(userInput.contains(","))) {
            for (int x = 0; x < myHash.size(); x++) {
                myHash.put(myHash.toString(), x);
            }
            System.out.println(userInput);
            exit(0);
        }
        
    }
    
}
